export interface projects {
  name: string,
  code: string,
  budget: number
}

export interface getProject {
  data: {
    id: string
    name: string
    code: string
    budget: number
    is_active: boolean
    created_at: Date
    updated_at: Date
  }
}

export interface timesheetProjectData {
  id: string
  name: string
  code: string
  budget: number
  is_active: boolean
  created_at: Date
  updated_at: Date
}




