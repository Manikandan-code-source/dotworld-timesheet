import React, { useContext, useEffect, useRef, useState } from 'react';
import type { InputRef } from 'antd';
import { Button, Form, Input, Table, DatePicker, Space, Select, InputNumber } from 'antd';
import type { FormInstance } from 'antd/es/form';
import type { DatePickerProps } from 'antd';
import dayjs from 'dayjs';
import isoWeek from 'dayjs/plugin/isoWeek'
import weekyear from 'dayjs/plugin/weekOfYear';
import ProjectServices from "@services/project";
import TimeSheetServices from "@services/timesheet";

dayjs.extend(isoWeek);
dayjs.extend(weekyear);

interface TypeDatasource {
    key: string,
    Task: string,
    Project: string,
    [x: string]: string,

}

interface Item {
    key: string;
    Project: string
}

interface EditableRowProps {
    index: number;
}

interface EditableCellProps {
    title: React.ReactNode;
    editable: boolean;
    children: React.ReactNode;
    dataIndex: keyof Item;
    record: Item;
    handleSave: (record: Item) => void;
}


type EditableTableProps = Parameters<typeof Table>[0];

type ColumnTypes = Exclude<EditableTableProps['columns'], undefined>;

const TimeSheet: React.FC = () => {

    const [columnsdata, setColumnsdata] = useState<string[]>()

    const [count, setCount] = useState(2);


    const [weekDay, setWeekDay] = useState<string>()

    const [dataSource, setDataSource] = useState<TypeDatasource[]>([]);

    const [project, getProjects] = useState<any[]>([])
    const [timeSheetData,getTimesheetData] = useState<any[]>()


    useEffect(() => {
        getData()
        getTimesheets()
    }, [])



    async function getData() {
        const res = await ProjectServices.list()
        getProjects(res.data);
    }


    const getTimesheets = async () => {
        const resp = await TimeSheetServices.list(weekDay)
        getTimesheetData(resp.data)
    }
    const EditableContext = React.createContext<FormInstance<any> | null>(null);



    const EditableRow: React.FC<EditableRowProps> = ({ index, ...props }) => {
        const [form] = Form.useForm();
        return (
            <Form form={form} component={false}>
                <EditableContext.Provider value={form}>
                    <tr {...props} />
                </EditableContext.Provider>
            </Form>
        );
    };


    const EditableCell: React.FC<EditableCellProps> = ({
        title,
        editable,
        children,
        dataIndex,
        record,
        handleSave,
        ...restProps
    }) => {


        const [editing, setEditing] = useState(false);
        const inputRef = useRef<InputRef>(null);
        const form = useContext(EditableContext)!;



        useEffect(() => {
            if (editing) {
                inputRef.current!?.focus();
            }
        }, [editing]);

        const toggleEdit = () => {
            setEditing(!editing);

            form.setFieldsValue({ [dataIndex]: record[dataIndex] });
        };



        const save = async () => {
            try {
                const values = await form.validateFields();

                toggleEdit();
                handleSave({ ...record, ...values });

            } catch (errInfo) {
                console.log('Save failed:', errInfo);
            }
        };

        let childNode = children;

        if (editable) {
            childNode = editing ? (
                <>
                    {title === "Project" ? (
                        <Form.Item
                            style={{ margin: 0 }}
                            name={dataIndex}
                            rules={[
                                {
                                    required: true,
                                    message: `${title} is required.`,
                                },
                            ]}
                        >
                            <Select
                                style={{ width: 120 }}
                                onSelect={save}
                                onBlur={save}
                                options={project?.map(item => ({ value: item.id, label: item.name }))}
                            />
                        </Form.Item>
                    ) :
                        title === "Task" ? (
                            <Form.Item
                                style={{ margin: 0 }}
                                name={dataIndex}
                                rules={[
                                    {
                                        required: true,
                                        message: `${title} is required.`,
                                    },
                                ]}
                            >
                                <Input ref={inputRef} onPressEnter={save} onBlur={save} />
                            </Form.Item>
                        )



                            : (
                                <Form.Item
                                    style={{ margin: 0 }}
                                    name={dataIndex}
                                    rules={[
                                        {
                                            required: true,
                                            message: `${title} is required.`,
                                        },
                                    ]}
                                >
                                    <InputNumber type='number' ref={inputRef} onPressEnter={save} onBlur={save} min={0} max={8} />
                                </Form.Item>
                            )}

                </>

            ) : (
                <div className="editable-cell-value-wrap" style={{ paddingRight: 24 }} onClick={toggleEdit}>
                    {
                        dataIndex === "Project" ?
                            <>
                                <Form.Item
                                    style={{ margin: 0 }}
                                    name={dataIndex}
                                    rules={[
                                        {
                                            required: true,
                                            message: `${title} is required.`,
                                        },
                                    ]}
                                    initialValue={record?.Project}
                                >
                                    <Select
                                        style={{ width: 120 }}
                                        onSelect={save}
                                        onBlur={save}
                                        options={project?.map(item => ({ value: item.id, label: item.name }))}
                                    />
                                </Form.Item>
                            </> : children}

                </div>
            );
        }

        return <td {...restProps}>{childNode}</td>;
    };





    useEffect(() => {
        const result = columnsdata?.reduce((obj, string) => {
            obj[string] = 0
            return obj
        }, { key: dataSource.length } as any)
        setDataSource([result])
    }, [columnsdata])




    const handleDates: DatePickerProps['onChange'] = (datetype: dayjs.Dayjs | null) => {
        const formattedDate = dayjs(datetype).format('YYYY')
        const year = Number(formattedDate) // for year
        const dateformate = dayjs(datetype).format('YYYY-MM-DD');
        const date = dayjs(dateformate)
        const weekCount = date.week();// for week

        // finding week first day using year and week count
        const findFirstDayOfWeek = dayjs().year(year).week(weekCount).startOf('week').day(0);

        const firstDayOfWeek = findFirstDayOfWeek.format('YYYY-MM-DD') // for first day of the week





        let firstMondayOfYear = dayjs().year(year).isoWeek(Number(weekCount)).day(1);

        if (firstMondayOfYear.year() !== year) {
            firstMondayOfYear = firstMondayOfYear.add(7, "days");
        }
        const res = new Array(7)
            .fill(firstMondayOfYear)
            .map((day, idx) => day.add(idx, "day").startOf('date').format("YYYY-MM-DD"))



        setColumnsdata(["Project", "Task", ...res]);

        let isoresult = dayjs(firstDayOfWeek).toISOString();

        setWeekDay(isoresult)
    }





    const defaultColumns: (ColumnTypes[number] & { title: string; editable?: boolean; dataIndex: string })[] | undefined = columnsdata?.map(e => {
        return {
            title: e,
            dataIndex: e,
            editable: true
        }
    })

    const handleAdd = () => {
        const newData = columnsdata?.reduce((obj, string) => {
            obj[string] = 0
            return obj
        }, { key: count } as any)
        setDataSource([...dataSource, newData] as any);

        setCount(count + 1);
    };

    const handleSave = (row: any) => {
        const newData = [...dataSource];
        const index = newData.findIndex((item) => row.key === item.key);
        const item = newData[index];
        newData.splice(index, 1, {
            ...item,
            ...row,
        });
        setDataSource(newData);
    };

    const components = {
        body: {
            row: EditableRow,
            cell: EditableCell,
        },
    };



    const columns = defaultColumns?.map((col) => {
        if (!col.editable) {
            return col;
        }
        return {
            ...col,
            onCell: (record: any) => ({
                record,
                editable: col.editable,
                dataIndex: col.dataIndex,
                title: col.title,
                handleSave,
            }),
        };
    });




    async function handleSaveData() {
        const result: any = [];

        dataSource.forEach((item) => {

            const keys = Object.keys(item).filter((key) => key !== "key");

            keys.forEach((key) => {
                if (key !== "Project" && key !== "Task") {
                    result.push({
                        week: weekDay,
                        description: item.Task,
                        project_id: project?.find((obj) => obj.id === item.Project)?.id,
                        duration: item[key],
                        date: dayjs(key).toISOString()
                    });
                }
            });
        });

        // await TimeSheetServices.create(result)


    }

    return (
        <>
            <div className='flex justify-between mb-6'>
                <Space direction="vertical">
                    <DatePicker onChange={handleDates} picker="week" />
                </Space>
                <div>
                    <Button onClick={handleAdd} style={{ backgroundColor: "blue", marginRight: 10 }} type="primary">
                        Add Rows
                    </Button>
                    <Button onClick={handleSaveData} style={{ backgroundColor: "blue" }} type="primary">
                        Save
                    </Button>
                </div>
            </div>
            <Table
                components={components}
                rowClassName={() => 'editable-row'}
                bordered
                dataSource={dataSource}
                columns={columns as ColumnTypes}
            />
        </>
    )
}

export default TimeSheet;
