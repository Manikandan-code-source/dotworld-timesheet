const Dashboard = () => {
  return <p>Dashboard Under development</p>;
};

export default Dashboard;
