import { Table } from 'antd';
import ProjectServices from "@services/project";
import { useEffect, useState } from 'react';
import { Button, Space } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import { Drawer } from 'antd';
import "./index.css"
import CreateProject from './createProject';

export default function Projects() {

  const [project, getProjects] = useState()

  useEffect(() => {
    getData()
  }, [])

  async function getData() {
    const res = await ProjectServices.list()
    getProjects(res.data);

  }

  const [open, setOpen] = useState(false);

  const showDrawer = () => {
    setOpen(true);
  };

  const onClose = () => {
    setOpen(false);
  };

  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: 'Code',
      dataIndex: 'code',
      key: 'code',
    },
    {
      title: 'Budget',
      dataIndex: 'budget',
      key: 'budget',
    }
  ];


  return (
    <div>
      <div className='flex justify-between'>
        <h2 className="mb-6 text-center text-3xl font-bold tracking-tight text-gray-900">
          List of Projects :
        </h2>
        <Button style={{ backgroundColor: "blue" }} type="primary" onClick={showDrawer} icon={<PlusOutlined />}>
          New account
        </Button>
        <Drawer
          title="Create a new project"
          width={720}
          onClose={onClose}
          closable={false}  
          open={open}
          bodyStyle={{ paddingBottom: 80 }}
          extra={
            <Space>
              <Button danger onClick={onClose}>Cancel</Button>

            </Space>
          }
        >
          <CreateProject />
        </Drawer>


      </div>
      <Table columns={columns} dataSource={project} />
    </div>
  )
}
