import request from "@utils/request";
import { Resp } from "src/types/common";


interface TimesheetResponse {
  id: string,
  week: Date,
  date: Date,
  description: string,
  duration: number,
  project_id: string,
  user_id: string
}


interface CreateTimesheet extends Response {
  week: Date,
  date: Date,
  description: string,
  duration: number,
  project_id: string,
}



export async function list(
  week: string | undefined,
): Promise<Resp<TimesheetResponse[]>> {
  return request(`http://localhost:8000/api/v1/timesheet/${week}`, {
    method: "GET"
  });
}


async function create(
  data: CreateTimesheet[]
): Promise<Resp<CreateTimesheet[]>> {
  return request(`http://localhost:8000/api/v1/timesheet`, {
    method: "POST",
    data: data
  });
}

export default { list, create }

