import request from "@utils/request";

import { projects } from "src/types/types";



async function create(
  name: string,
  code: string,
  budget: number
): Promise<projects> {
  return request(`http://localhost:8000/api/v1/projects`, {
    method: "POST",
    data: {
      name: name,
      code: code,
      budget: budget
    },
  });
}

async function list() {
  return request(`http://localhost:8000/api/v1/projects`, {
    method: "GET"
  });
}

export default { create,list }




