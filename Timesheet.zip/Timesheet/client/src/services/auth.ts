import request from "@utils/request";

export const HOST = import.meta.env.VITE_APP_BACKEND;

interface LoginResponse extends Response {
  data: {
    token: string
    user: {
      id: string,
      email: string,
      name: string
    }
  }
}

export async function login(
  email: string,
  password: string
): Promise<LoginResponse> {
  return request(`http://localhost:8000/api/v1/auth`, {
    method: "POST",
    data: {
      email: email,
      password: password,
    },
  });
}
