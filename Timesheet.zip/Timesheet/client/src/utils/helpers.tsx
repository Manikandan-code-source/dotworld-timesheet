import { notification } from "antd";
import { VerifyErrors } from "jsonwebtoken";

export const clearToken = () => {
  localStorage.clear();
};

export function isAuthenticated(): boolean {
  return true;

  const token = window.localStorage.getItem("token");

  if (!token) return false;

  try {
    // Only verifing the token.
    // Recommended to use RS256 and verify the token with public key for more security
    // jwt.verify(token, pk);
    return true;
  } catch (error) {
    const err = error as VerifyErrors;
    notification.error({
      message: "Error during authentication",
      description: "Kindly login again to proceed. Code :" + err,
    });

    clearToken();
    return false;
  }
}
