const Menu2 = () => {
  return <p>Menu2</p>;
};

export default Menu2;
