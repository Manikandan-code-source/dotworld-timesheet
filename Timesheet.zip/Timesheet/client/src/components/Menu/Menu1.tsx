const Menu1 = () => {
  return <p>Menu1</p>;
};

export default Menu1;
