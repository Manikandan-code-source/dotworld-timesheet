
  // let project_id = timesheet.map(e => {
    //   e.project_id
    // })
    // let exsistingProject = await this.prisma.project.findUnique({
    //   where: {
    //     id : project_id
    //   }
    // })
    // let user_id = timesheet.map(e => {
    //   e.user_id
    // })
    // let exsistingUser = await this.prisma.project.findUnique({
    //   where: {
    //     id : project_id
    //   }
    // })

    // if (!exsistingProject) {
    //   throw new HttpError(404, "Project not found");
    // }
    // else if (!exsistingUser){
    //   throw new HttpError(404, "po not found");
    // }
    // else if (project_id && user_id){
    //   let Timesheet = await this.prisma.timeSheet.createMany({
    //     data: timesheet,
    //   });
    //   return Timesheet;
    // }