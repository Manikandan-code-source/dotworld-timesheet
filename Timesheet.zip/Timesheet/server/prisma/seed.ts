require("dotenv").config();

import { PrismaClient, Prisma } from "@prisma/client";
const prisma = new PrismaClient();

const userData: Prisma.UserCreateInput[] = [
  {
    email: "naveen@dotworld.in",
    first_name: "Naveen",
    last_name: "Sakthivel",
    password: "$2b$10$35Yj/xwL2rY6nkRRyJOQQOef2TEK3FARaxcCKjEHOt1fWbMoeXhD2",
    mobile_number: "6745909090"
  },
  {
    first_name: "Hari",
    last_name: "sudhan",
    email: "hari@dotworld.com",
    password: "$2b$10$35Yj/xwL2rY6nkRRyJOQQOef2TEK3FARaxcCKjEHOt1fWbMoeXhD2",
    mobile_number: "6789567867"
},
{
    first_name: "hema",
    last_name: "krishnan",
    email: "hema@dotworld.com",
    password: "$2b$10$35Yj/xwL2rY6nkRRyJOQQOef2TEK3FARaxcCKjEHOt1fWbMoeXhD2",
    mobile_number: "6945236789"
  
}
];

async function main() {
  console.log(`Start seeding ...`);

  for (const u of userData) {
    const user = await prisma.user.upsert({
      where: {
        email: u.email,
      },
      update: {},
      create: u,
    });
    console.log(`Created user with id: ${user.id}`);
  }
  console.log(`Seeding finished.`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
