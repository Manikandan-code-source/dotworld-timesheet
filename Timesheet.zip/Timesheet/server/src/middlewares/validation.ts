import { celebrate, Joi, Segments } from "celebrate";

const loginSchema = celebrate({
  [Segments.BODY]: Joi.object({
    email: Joi.string().email().required().trim(),
    password: Joi.string().required(),
  }),
});

const tokenExchangeSchema = celebrate({
  [Segments.BODY]: Joi.object({
    token: Joi.string().required().trim(),
  }),
});



const uuidParam = celebrate({
  [Segments.PARAMS]: {
    id: Joi.string().uuid().required(),
  },
});

const deviceTokenSchema = celebrate({
  [Segments.BODY]: Joi.object({
    device_token: Joi.string().uuid().required(),
  }),
});

export default {
  loginSchema,
  tokenExchangeSchema,
  uuidParam,
  deviceTokenSchema,
};
