import { Inject, Service } from "typedi";
import { Logger } from "winston";
import { Prisma, PrismaClient } from "@prisma/client";
import { HttpError } from "../api/errors";
import { ProjectUpdateCheckerDTO } from "../interface/Project";
@Service()
export default class ProjectService {
  constructor(
    @Inject("logger") private logger: Logger,
    @Inject("prisma") private prisma: PrismaClient
  ) { }

  public async ListProjects() {
    this.logger.silly("🤵🤵 Listing projects");
    let projects = await this.prisma.project.findMany({
      where: {
        is_active: true
      }
    });
    return projects;
  }

  public async CreateProjects(project: Prisma.ProjectCreateInput) {
    this.logger.silly("🤵 Creating new project");
    let Project = await this.prisma.project.create({
      data: project,
    });
    return Project
  }

  public async UpdateProject(id: string, data: ProjectUpdateCheckerDTO) {
    this.logger.silly("🤵 Update project");
    let exsistingProject = await this.prisma.project.findUnique({
      where: {
        id
      }
    })

    if (!exsistingProject) {
      throw new HttpError(404, "Project not found");
    }

    let project = await this.prisma.project.update({
      where: {
        id
      },
      data
    });

    return project;
  }

  public async DeleteProject(id: string) {
    this.logger.silly("🤵 Delete project");

    let project = await this.prisma.project.update({
      where: {
        id
      },
      data: {
        is_active: false,
      },
    });

    return project;
  }
}
