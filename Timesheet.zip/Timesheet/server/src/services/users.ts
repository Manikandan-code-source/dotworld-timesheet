import { Inject, Service } from "typedi";
import { Logger } from "winston";
// import { HttpError } from "../api/errors";
import { PrismaClient } from "@prisma/client";


@Service()
export default class UserService {
  constructor(
    @Inject("logger") private logger: Logger,
    @Inject("prisma") private prisma: PrismaClient
  ) { }

  public async ListUsers() {
    this.logger.silly("🤵🤵 Listing users");
    let users = await this.prisma.user.findMany({
      select: {
        id: true,
        first_name: true,
        last_name: true,
        email: true,
        password: true,
        mobile_number: true,
        last_login: true,
        created_at: true,
        updated_at: true,
      },
    });

    return users;
  }

  // public async GetUser(id: any) {
  //   this.logger.silly("🤵 Finding user with id " + id);
  //   let user = await this.prisma.user.findUnique({
  //     where: {
  //       id,
  //     },
  //   });

  //   if (user) {
  //     delete user.password;
  //     delete user.email;
  //     delete user.mobile_number;
  //   } else {
  //     throw new HttpError(404, "User not found");
  //   }

  //   return user;
  // }


}
