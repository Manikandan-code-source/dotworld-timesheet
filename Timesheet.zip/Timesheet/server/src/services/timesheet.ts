import { Inject, Service } from "typedi";
import { Logger } from "winston";
import { Prisma, PrismaClient } from "@prisma/client";
@Service()
export default class ProjectService {
  constructor(
    @Inject("logger") private logger: Logger,
    @Inject("prisma") private prisma: PrismaClient
  ) { }

  public async ListTimesheet(week : string | Date) {
    this.logger.silly("🤵🤵 Listing Timesheet");
    let timesheet = await this.prisma.timeSheet.findMany({
      where: {
        week: new Date(week)
      }
    });
    return timesheet;
  }

  public async CreateTimesheet(timesheet: Prisma.TimeSheetCreateManyInput[],userid : string) {
    this.logger.silly("🤵🤵 Create Timesheet");
    const TimeSheetData = timesheet.map(obj => ({
      ...obj,
      user_id : userid
    }))
    for (const i of TimeSheetData) {
      let result = TimeSheetData.some(e => e.id)
      if (result === true) {
        await this.prisma.timeSheet.upsert({
          where: { id: i.id },
          create: {
            duration: i.duration,
            date: i.date,
            description: i.description,
            week: i.week,
            project_id: i.project_id,
            user_id: i.user_id
          },
          update: {
            ...i
          }
        });
      }
      else {
        await this.prisma.timeSheet.create({
          data: i
        })
      }
    }

  }
}

