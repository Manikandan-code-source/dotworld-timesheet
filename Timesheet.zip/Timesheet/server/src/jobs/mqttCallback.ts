import { Packet } from "mqtt-packet";
import Logger from "../loaders/logger";

enum Topic {
  WILL = "/dotworld/beambox/will",
}



function onMessage(topic: string, payload: Buffer, _: Packet) {
  Logger.info("🛸 Received : " + payload.toString());

  switch (topic) {
    case Topic.WILL:
      
      break;
    default:
      Logger.info("📥 Unknown message received");
  }
}



export default onMessage;
