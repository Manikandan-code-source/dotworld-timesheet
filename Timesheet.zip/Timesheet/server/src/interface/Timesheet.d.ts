export interface TimesheetCreateInputDTO {
  id: string
  week: Date | string
  date: Date | string
  description: string
  duration: number
  project_id: string
  user_id: string
  created_at: Date | string
  updated_at: Date | string
}




export interface TimesheetUpdateInputDTO {
  id? : string
  week: Date | string
  date: Date | string
  description: string
  duration: number
  project_id: string
  user_id: string
}


