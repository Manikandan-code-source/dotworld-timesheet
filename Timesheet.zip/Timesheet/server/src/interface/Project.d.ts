export interface ProjectListDTD {
    id: string
    name: string
    code: string
    budget: number
    is_active: boolean
    created_at: Date
    updated_at: Date
  }
  

  export interface ProjectCreateInputDTO {
    name: string
    code: string
    budget: number
  }

  
  export interface ProjectUpdateDTO {
    name?: string
    code?: string
    budget?: number
    is_active?: boolean
  }


  export type ProjectUpdateCheckerDTO = {
    name?: string
    code?: string
    budget?: number
    is_active?: boolean
  }
