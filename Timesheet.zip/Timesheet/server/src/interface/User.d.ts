
export interface IUser {
  id: string;
  name: string;
  email: string;
  password?: string;
}

export interface TokenPayload {
  id: string;
  email: string;
}

export interface IUserLoginDTO {
  email: string;
  password: string;
}

export interface AssertionCredentialJSONExtra {
  email: string;
}
export interface UserListDTO {
  id: string;
  first_name: string;
  last_name: string;
  email: string;
  password: string;
  mobile_number: string;
  last_login: Date;
  created_at: Date;
  updated_at: Date;
}

export interface UserCreateInputDTO {
  first_name: string;
  last_name: string;
  email: string;
  password: string;
  mobile_number: string;
}

export interface UserFcmOutputDTO {
  id: string;
  first_name: string;
}

export interface UserUpdateDTO {
  first_name?: string;
  last_name?: string;
  email?: string;
  password?: string;
  mobile_number?: string;
}
/////////////////////////////////////0. 0 +
