export default {
  user: {
    login: "onUserLogin",
  },
  notification: {
    forgetPassword: "onForgetPassword",
    newAccount: "onNewAccountCreated",
    subscription: "onNewSubsctiption",
    magicLink: "onMagicLink",
  },
};
