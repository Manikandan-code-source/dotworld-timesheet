import { Router } from "express";

// Admin routes
export default () => {
  const app = Router();
  return app;
};
