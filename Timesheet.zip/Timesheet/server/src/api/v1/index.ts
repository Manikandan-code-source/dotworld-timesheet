import v1Admin from "./admin";
import v1User from "./user";

let routes = [v1Admin, v1User];

export default routes;
