import { Router } from "express";
import users from "./users";
import auth from "./auth";
import project from "./project"
import timesheet from "./timesheet"

export default () => {
  const app = Router();
  users(app);
  auth(app);
  project(app);
  timesheet(app);
  return app;
};
