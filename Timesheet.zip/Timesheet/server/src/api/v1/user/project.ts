import { Router, Request, Response, NextFunction } from "express";
import { celebrate, Joi } from "celebrate";
import { Logger } from "winston";
import { Container } from "typedi";
import ProjectService from "../../../services/project";
import { ProjectCreateInputDTO, ProjectUpdateDTO } from "../../../interface/Project";
import passport from "passport";
const route = Router();
export default (app: Router) => {
  app.use("/projects", route);

  // list project
  route.get(
    "/",
    passport.authenticate("jwt", { session: false }),
    async (_req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get("logger");
      try {
        const userProjectInstance = Container.get(ProjectService);
        const project = await userProjectInstance.ListProjects();

        return res.json({
          status: true,
          data: project,
        });
      } catch (e) {
        logger.error("🔥 error: %o", e);
        return next(e);
      }
    }
  );

  // create project
  route.post(
    "/",
    celebrate({
      body: Joi.object({
        name: Joi.string().required().normalize(),
        code: Joi.string().required().normalize(),
        budget: Joi.number().required(),
      }),
    }),
    passport.authenticate("jwt", { session: false }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get("logger");
      try {
        let data: ProjectCreateInputDTO = req.body;
        const projectServiceInstance = Container.get(ProjectService);
        const project = await projectServiceInstance.CreateProjects(data);

        return res.json({
          status: true,
          data: project,
        });
      } catch (e) {
        logger.error("🔥 error: %o", e);
        return next(e);
      }
    }
  )

  // update project
  route.patch(
    "/:id",
    celebrate({
      body: Joi.object({
        name: Joi.string().normalize().optional(),
        code: Joi.string().normalize().optional(),
        budget: Joi.number().optional(),
        is_active: Joi.boolean().optional()
      }),
    }),
    passport.authenticate("jwt", { session: false }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get("logger");
      try {
        const { id } = req.params;
        let data: ProjectUpdateDTO = req.body;
        const projectServiceInstance = Container.get(ProjectService);
        const project = await projectServiceInstance.UpdateProject(id, data);
        return res.json({
          status: true,
          data: project,
        });
      } catch (e) {
        logger.error("🔥 error: %o", e);
        return next(e);
      }
    }
  )

  // delete project
  route.delete(
    "/:id",
    passport.authenticate("jwt", { session: false }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get("logger");
      try {
        const { id } = req.params;
        const projectServiceInstance = Container.get(ProjectService);
        const project = await projectServiceInstance.DeleteProject(id);
        return res.json({
          status: true,
          data: project,
        });
      } catch (e) {
        logger.error("🔥 error: %o", e);
        return next(e);
      }
    }
  );
};
