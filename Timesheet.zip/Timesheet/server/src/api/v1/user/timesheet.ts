import { Router, Request, Response, NextFunction } from "express";
import { Logger } from "winston";
import { Container } from "typedi";
import { celebrate, Joi } from "celebrate";
import TimesheetService from "../../../services/timesheet";
// import { TimesheetUpdateInputDTO } from "../../../interface/Timesheet";

import passport from "passport";
const route = Router();

export default (app: Router) => {
  app.use("/timesheet", route);

  // list timesheet data
  route.get("/:week",
    passport.authenticate("jwt", { session: false }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get("logger");
      try {
        const { week } = req.params;
        const timesheetInstance = Container.get(TimesheetService);
        const timesheet = await timesheetInstance.ListTimesheet(week);
        return res.json({
          status: true,
          data: timesheet,
        });
      } catch (e) {
        logger.error("🔥 error: %o", e);
        return next(e);
      }
    }
  )

  // create timesheet
  route.post(
    "/",
    celebrate({
      body: Joi.array().items(Joi.object().keys({
        id: Joi.string().optional(),
        week: Joi.date().required(),
        date: Joi.date().required(),
        description: Joi.string().required().normalize(),
        duration: Joi.number().required(),
        project_id: Joi.string().required().normalize(),
        user_id: Joi.string().required().optional()
      })),
    }),
    passport.authenticate("jwt", { session: false }),
    async (req: Request, res: Response, next: NextFunction) => {
      const logger: Logger = Container.get("logger");
      try {
        let data = req.body;
        const {id}=req.user        
        const timesheetServiceInstance = Container.get(TimesheetService);
        const timesheet = await timesheetServiceInstance.CreateTimesheet(data,id);

        return res.json({
          status: true,
          data: timesheet,
        });
      } catch (e) {
        logger.error("🔥 error: %o", e);
        return next(e);
      }
    }
  )

}